<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Lista de funciones</title>
</head>
<body>
<a href="<?php echo e(route('funciones.create')); ?>">Añadir Funcion</a>
    <h1>Funciones</h1>
    <table>
        <thead>
            <tr>
                <th>Película</th>
                <th>Fecha</th>
                <th>Hora</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $funciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($funcion->pelicula); ?></td>
                    <td><?php echo e($funcion->fecha); ?></td>
                    <td><?php echo e($funcion->hora); ?></td>
                    <td>
                        <a>
                        <form method="post" action ="<?php echo e(route('funciones.destroy', $funcion->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit"> Eliminar </button>
                        </form>
                        </a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\Users\Alejandra Ceniceros\Desktop\examen\ExamenCine\resources\views/funciones/index.blade.php ENDPATH**/ ?>